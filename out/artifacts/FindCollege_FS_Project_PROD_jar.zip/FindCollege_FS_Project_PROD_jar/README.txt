TO RUN: 
Make sure u have java 14.0.1
type "cmd" in the address bar and then type the following:
java -jar "FindCollege-FS-Project-PROD.jar"
